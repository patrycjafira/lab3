
import { CartProvider } from "./cart/cartContext";
import ProductList from "./components/ProductList";
import Cart from "./components/Cart";

function App() {
  return (
    <CartProvider>
      <main style={{ padding: 20 }}>
        <h1>Sklep internetowy</h1>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "2fr 1fr",
            gap: 24,
            alignItems: "start",
          }}
        >
          <ProductList />
          <Cart />
        </div>
      </main>
    </CartProvider>
  );
}

export default App;
