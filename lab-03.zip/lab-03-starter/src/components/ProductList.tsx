
import { products } from "../data/products";
import { formatPrice } from "../utils";
import { useCart } from "../cart/cartContext";

export default function ProductList() {
  const { dispatch } = useCart();

  return (
    <section>
      <h2>Produkty</h2>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))",
          gap: 12,
        }}
      >
        {products.map((product) => (
          <article
            key={product.id}
            style={{
              background: "var(--card)",
              border: "1px solid var(--border)",
              borderRadius: 12,
              padding: 16,
            }}
          >
            <div style={{ fontSize: "2.5rem" }}>
              {product.emoji}
            </div>

            <h3 style={{ fontSize: "1rem" }}>
              {product.name}
            </h3>

            <p>
              <strong>{formatPrice(product.price)}</strong>
            </p>

            <button
              className="primary"
              onClick={() =>
                dispatch({
                  type: "added",
                  product,
                })
              }
            >
              Dodaj do koszyka
            </button>
          </article>
        ))}
      </div>
    </section>
  );
}