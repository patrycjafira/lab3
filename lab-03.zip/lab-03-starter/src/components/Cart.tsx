
import { useCart } from "../cart/cartContext";
import { formatPrice } from "../utils";

export default function Cart() {
  const { state, dispatch, totalCount, totalPrice } = useCart();

  return (
    <section
      aria-label="Koszyk"
      style={{
        background: "var(--card)",
        border: "1px solid var(--border)",
        borderRadius: 12,
        padding: 16,
        height: "fit-content",
      }}
    >
      <h2>Koszyk ({totalCount})</h2>

      {state.items.length === 0 ? (
        <p>Koszyk jest pusty.</p>
      ) : (
        <>
          {state.items.map((item) => (
            <article
              key={item.product.id}
              style={{
                borderBottom: "1px solid var(--border)",
                padding: "12px 0",
              }}
            >
              <h3>{item.product.name}</h3>

              <p>
                Cena: {formatPrice(item.product.price)}
              </p>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  flexWrap: "wrap",
                }}
              >
                <button
                  aria-label={`Zmniejsz ilość: ${item.product.name}`}
                  onClick={() =>
                    dispatch({
                      type: "quantity_changed",
                      productId: item.product.id,
                      quantity: item.quantity - 1,
                    })
                  }
                >
                  −
                </button>

                <span aria-live="polite">
                  {item.quantity}
                </span>

                <button
                  aria-label={`Zwiększ ilość: ${item.product.name}`}
                  onClick={() =>
                    dispatch({
                      type: "quantity_changed",
                      productId: item.product.id,
                      quantity: item.quantity + 1,
                    })
                  }
                >
                  +
                </button>

                <button
                  aria-label={`Usuń produkt: ${item.product.name}`}
                  onClick={() =>
                    dispatch({
                      type: "removed",
                      productId: item.product.id,
                    })
                  }
                >
                  ✕
                </button>
              </div>

              <p>
                <strong>
                  Razem:{" "}
                  {formatPrice(
                    item.quantity * item.product.price
                  )}
                </strong>
              </p>
            </article>
          ))}

          <h3>
            Suma zamówienia: {formatPrice(totalPrice)}
          </h3>

          <button
            onClick={() => dispatch({ type: "cleared" })}
          >
            Wyczyść koszyk
          </button>
        </>
      )}
    </section>
  );
}
