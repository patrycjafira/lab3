import type { Product } from "../types";

export const products: Product[] = [
  { id: 1, name: "Klawiatura mechaniczna", price: 329, emoji: "⌨️" },
  { id: 2, name: "Mysz bezprzewodowa", price: 129.9, emoji: "🖱️" },
  { id: 3, name: "Monitor 27\"", price: 899, emoji: "🖥️" },
  { id: 4, name: "Słuchawki", price: 249, emoji: "🎧" },
  { id: 5, name: "Kamera internetowa", price: 179, emoji: "📷" },
  { id: 6, name: "Podkładka pod mysz", price: 39.99, emoji: "🟦" },
];
