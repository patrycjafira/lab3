export type Product = {
  id: number;
  name: string;
  price: number;
  emoji: string;
};

export type CartItem = {
  product: Product;
  quantity: number;
};
