
import {
  createContext,
  useContext,
  useMemo,
  useReducer,
  useEffect,
  type Dispatch,
  type ReactNode,
} from "react";

import {
  cartReducer,
  initialCartState,
  selectTotalCount,
  selectTotalPrice,
  type CartState,
  type CartAction,
} from "./cartReducer";

const STORAGE_KEY = "lab03-cart";

type CartContextValue = {
  state: CartState;
  dispatch: Dispatch<CartAction>;
  totalCount: number;
  totalPrice: number;
};

export const CartContext = createContext<CartContextValue | null>(null);

type CartProviderProps = {
  children: ReactNode;
};


function loadInitialState(): CartState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);

    return raw
      ? (JSON.parse(raw) as CartState)
      : initialCartState;
  } catch {
    return initialCartState;
  }
}

export function CartProvider({ children }: CartProviderProps) {
  const [state, dispatch] = useReducer(
    cartReducer,
    initialCartState,
    loadInitialState
  );

 
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(state)
      );
    } catch {
      console.error("Nie udało się zapisać koszyka w localStorage.");
    }
  }, [state]);

  const totalCount = selectTotalCount(state);
  const totalPrice = selectTotalPrice(state);

  const value = useMemo(
    () => ({
      state,
      dispatch,
      totalCount,
      totalPrice,
    }),
    [state, totalCount, totalPrice]
  );

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart(): CartContextValue {
  const context = useContext(CartContext);

  if (context === null) {
    throw new Error(
      "useCart must be used within a CartProvider"
    );
  }

  return context;
}
