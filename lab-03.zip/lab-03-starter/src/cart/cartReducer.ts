
import type { CartItem, Product } from "../types";

export type CartState = {
  items: CartItem[];
};

export type CartAction =
  | { type: "added"; product: Product }
  | { type: "removed"; productId: number }
  | { type: "quantity_changed"; productId: number; quantity: number }
  | { type: "cleared" };

export const initialCartState: CartState = { items: [] };

export function cartReducer(
  state: CartState,
  action: CartAction
): CartState {
  switch (action.type) {
    case "added": {
      const existing = state.items.find(
        (i) => i.product.id === action.product.id
      );

      if (existing) {
        return {
          ...state,
          items: state.items.map((i) =>
            i.product.id === action.product.id
              ? { ...i, quantity: i.quantity + 1 }
              : i
          ),
        };
      }

      return {
        ...state,
        items: [
          ...state.items,
          {
            product: action.product,
            quantity: 1,
          },
        ],
      };
    }

    case "removed": {
      return {
        ...state,
        items: state.items.filter(
          (i) => i.product.id !== action.productId
        ),
      };
    }

    case "quantity_changed": {
      if (action.quantity <= 0) {
        return {
          ...state,
          items: state.items.filter(
            (i) => i.product.id !== action.productId
          ),
        };
      }

      return {
        ...state,
        items: state.items.map((i) =>
          i.product.id === action.productId
            ? { ...i, quantity: action.quantity }
            : i
        ),
      };
    }

    case "cleared": {
      return {
        ...state,
        items: [],
      };
    }

    default: {
  const _exhaustive: never = action;
  throw new Error(`Unhandled action: ${_exhaustive}`);
}
  }
}

export const selectTotalCount = (state: CartState): number =>
  state.items.reduce((total, item) => total + item.quantity, 0);

export const selectTotalPrice = (state: CartState): number =>
  state.items.reduce(
    (total, item) => total + item.quantity * item.product.price,
    0
  );
